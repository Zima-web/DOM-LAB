const tasks = [
    { text: "Revise DOM selectors", done: false },
    { text: "Push Lab Sheet 01 to GitHub", done: true },
    { text: "Read MDN: Introduction to events", done: false }
];


const form = document.getElementById("task-form");
const input = document.getElementById("task-input");
const message = document.getElementById("message");
const list = document.getElementById("task-list");
const summary = document.getElementById("summary");


function createTaskItem(task, index) {

    const li = document.createElement("li");

    li.dataset.index = index;

    if (task.done) {
        li.classList.add("done");
    }

    const span = document.createElement("span");
    span.textContent = task.text;

    const button = document.createElement("button");
    button.type = "button";
    button.classList.add("delete-btn");
    button.textContent = "✕";

    li.append(span, button);

    return li;
}


function render() {

    list.textContent = "";

    tasks.forEach((task, i) => {
        list.append(createTaskItem(task, i));
    });

    const total = tasks.length;

    const done = tasks.filter(task => task.done).length;

    const remaining = total - done;

    summary.textContent =
        total + " tasks | " +
        done + " done | " +
        remaining + " to go";
}


form.addEventListener("submit", (e) => {

    e.preventDefault();

    const text = input.value.trim();

    if (text === "") {
        message.textContent = "Please enter a task.";
        return;
    }

    tasks.push({
        text: text,
        done: false
    });

    input.value = "";

    message.textContent = "Task added.";

    render();
});


list.addEventListener("click", (e) => {

    const item = e.target.closest("li");

    if (!item) return;

    const index = Number(item.dataset.index);

    if (e.target.classList.contains("delete-btn")) {

        tasks.splice(index, 1);

    } else {

        tasks[index].done = !tasks[index].done;

    }

    render();
});


render();