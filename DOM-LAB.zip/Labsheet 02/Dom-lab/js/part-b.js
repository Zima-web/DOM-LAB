const greetBtn = document.getElementById("greet-btn");
const themeBtn = document.getElementById("theme-btn");
const message = document.getElementById("message");
const title = document.getElementById("title");

greetBtn.addEventListener("click", () => {
    const time = new Date().toLocaleTimeString();
    message.textContent = "Hello! The time is " + time;
});

themeBtn.addEventListener("click", () => {
    document.body.classList.toggle("dark");

    if (document.body.classList.contains("dark")) {
        themeBtn.textContent = "Light mode";
    } else {
        themeBtn.textContent = "Dark mode";
    }
});

let counter = 0;

title.addEventListener("click", () => {
    counter++;
    message.textContent = "Title clicked " + counter + " times";
});


const nameBox = document.getElementById("name-input");
const preview = document.getElementById("preview");
const count = document.getElementById("counter");

nameBox.addEventListener("input", () => {
    const name = nameBox.value.trim();

    if (name === "") {
        preview.textContent = "";
    } else {
        preview.textContent = "Hello, " + name + "!";
    }

    count.textContent = nameBox.value.length + " / 20";

    count.classList.toggle("error", nameBox.value.length > 20);
});

const menuItems = document.querySelectorAll(".item");

menuItems.forEach((item) => {
    item.addEventListener("mouseover", () => {
        item.classList.add("highlight");
    });

    item.addEventListener("mouseout", () => {
        item.classList.remove("highlight");
    });
});


nameBox.addEventListener("keydown", (e) => {
    console.log(e.key);

    if (e.key === "Enter") {
        message.textContent = "Saved name: " + nameBox.value;
    }
});

const links = document.querySelectorAll(".nav-link");

links.forEach((link) => {
    link.addEventListener("click", (e) => {
        e.preventDefault();

        links.forEach((item) => {
            item.classList.remove("active");
        });

        e.target.classList.add("active");

        message.textContent = "You chose " + e.target.textContent;
    });
});


const menuList = document.getElementById("menu-list");

menuList.addEventListener("click", (e) => {
    const item = e.target.closest("li");

    if (!item) return;

    console.log(e.target, e.currentTarget);

    item.classList.toggle("done");
});

menuList.addEventListener("dblclick", (e) => {
    const item = e.target.closest("li");

    if (!item) return;

    item.remove();
});