const title = document.getElementById("title");

const tagline = document.querySelector(".tagline");

const menuList = document.getElementById("menu-list");

const menuItems = document.querySelectorAll(".item");

const message = document.getElementById("message");

console.log(title);
console.log(tagline);
console.log(menuList);
console.log(menuItems);
console.log(message);


title.textContent = "Lagoon Café · Open now";

tagline.textContent = "Fresh food by the lagoon since 2010";

menuItems.forEach((item, index) => {
    item.textContent = (index + 1) + ". " + item.textContent;
});

message.innerHTML = "<strong>Welcome!</strong> Today's special is crab curry.";

const nameBox = document.getElementById("name-input");

console.log(nameBox.value);


const specialItem = document.querySelector(".special");
specialItem.classList.add("highlight");

const firstLink = document.querySelector(".nav-link");
firstLink.classList.add("active");

nameBox.setAttribute("placeholder", "Type your first name");

const hoursHeading = document.getElementById("hours");
hoursHeading.style.color = "crimson";

menuItems.forEach((item) => {
    console.log(item.textContent, item.classList.contains("special"));
});


// ===== A5: Creating and Removing Elements =====

// Create Egg hoppers
const egg = document.createElement("li");
egg.textContent = "Egg hoppers";
egg.classList.add("item");

menuList.append(egg);


// Create Drinks section
const drinks = ["Faluda", "King coconut", "Plain tea"];

const drinksHeading = document.createElement("h2");
drinksHeading.textContent = "Drinks";

const drinksList = document.createElement("ul");

drinks.forEach((drink) => {
    const li = document.createElement("li");
    li.textContent = drink;
    drinksList.append(li);
});

hoursHeading.before(drinksHeading, drinksList);


const items = document.querySelectorAll("#menu-list li");

items.forEach((item) => {
    if (item.textContent.includes("Kottu")) {
        item.remove();
    }
});